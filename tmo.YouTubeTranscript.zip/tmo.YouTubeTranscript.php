<?php
/*
  Plugin Name: tmo.YouTubeTranscript
  Description: From https://www.youtube.com/watch?v=37tAM7fLf7Y
                    https://www.youtube.com/watch?v=saC-7wTpZ_k
                    https://www.youtube.com/watch?v=I-P183PvRIQ
*/

defined( 'ABSPATH' ) || die( 'Unauthorized Access' );

add_shortcode('tmo.youtubetranscript','callback_youtubetranscript');

function callback_youtubetranscript(){

//
// Backend url
//	
$api = 'https://thomasmoor.org/transcribeyt';
  
$h = '<form method="post">';
$h .= '<label>Video URL: </label>';
$h .= '<input type="text" name="video"/> ';
$h .= '<input type="submit" name="submit" value="Transcript"/>';
  
if(isset($_POST['submit']) and isset($_POST['video']) and $_POST['video'] != ''){

  //$h .= '<br> api:' . $api;
  //$h .= '<br>video: ' . $_POST['video'];
  
  $body = array(
    'video' => sanitize_text_field($_POST['video'])
  );
  
  $arguments=array(
    'body'   => $body,
  );
  
  // API Call  
  $response = wp_remote_post($api,$arguments);
  $code=$response['response']['code'];
  $message=$response['response']['message'];
  if($code != '200'){
    $h .= '<br>Could not connect to API: ' . $url;
    $h .= '<br>Response: code: '.$code . ' message: ' . $message;
  return $h;
  }
    
  $body=$response['body'];

  $decode=json_decode($body,true);
  
  $transcript = $decode['transcript'];

} else if(isset($_POST['transcript'])) {
  $transcript=$_POST['transcript'];
} else {
  $transcript='';
}

// Download
if (isset($_POST['download'])){
  ob_clean();
  ob_end_clean();
  ob_start(null, 0, PHP_OUTPUT_HANDLER_CLEANABLE);
  header('Content-Type: text/csv');
  header('Content-Disposition: attachment; filename="thomasmoor.org.csv"');
  header('Pragma: no-cache');    
  header('Expires: 0');
  $message = "";
  $fp = fopen('php://output', 'w');
  fwrite($fp, $transcript);
}
  
$h .= "<br/>";
$h .= '<input type="submit" name="download" value="Download"/>';
$h .= '<textarea cols="100" rows="30" name="transcript">';
$h .= $transcript;
$h .= '</textarea>';
  
    
$h .= '</form>';
  
return $h;

} // callback

?>