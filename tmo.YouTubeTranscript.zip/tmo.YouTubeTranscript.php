<?php
/*
  Plugin Name: tmo.YouTubeTranscript
  Description: From https://www.youtube.com/watch?v=37tAM7fLf7Y
                    https://www.youtube.com/watch?v=saC-7wTpZ_k
                    https://www.youtube.com/watch?v=I-P183PvRIQ
*/

defined( 'ABSPATH' ) || die( 'Unauthorized Access' );

add_shortcode('youtubetranscript','callback_youtubetranscript');

function callback_youtubetranscript(){
	
$filename="tmo.youTubeTranscript.log";

//  return 'Call works';
$url = 'https://thomasmoor.org/transcribeyt';
  
file_put_contents($filename, "Test 0\n", FILE_APPEND);
$h = '<form method="post">';
$h .= '<label>Video URL: </label>';
$h .= '<input type="text" name="video"/> ';
$h .= '<input type="submit" name="submit" value="Transcript"/>';
  
if(isset($_POST['submit']) and isset($_POST['video']) and $_POST['video'] != ''){

  // https://developer.wordpress.org/apis/handbook/making-http-requests/posting-data-to-an-external-service/
  // To send data to the server you will need to build an associative array of data. 
  // This data will be assigned to the 'body' value. 
  // From the server side of things the value will appear in the $_POST variable 
  // if body => array( 'myvar' => 5 ) 
  // on the server $_POST['myvar'] = 5.
  
  $h .= '<br> url:' . $url;
  $h .= '<br>video: ' . $_POST['video'];
  
  $body = array(
    'video' => sanitize_text_field($_POST['video'])
  );
  
  $arguments=array(
    'body'   => $body,
  );
  
  // $h .= '<br>Test B - video=' . $arguments['body']['video'];
  
  // API Call  
  $response = wp_remote_post($url,$arguments);
  // response: array:
  //   'headers'       => array(),
  //   'body'          => '',
  //   'response'      => array(
  //     'code'    => false,
  //     'message' => false,
  //   ),
  //   'cookies'       => array(),
  //   'http_response' => null,
  $code=$response['response']['code'];
  $message=$response['response']['message'];
  file_put_contents($filename, "\n----  response ----\n", FILE_APPEND);
  file_put_contents($filename, 'code: ' .$code . ' message: ' . $message, FILE_APPEND);
  if($code != '200'){
    file_put_contents($filename, '\nError - ' . $url . ': ' . $code . ' - ' .$message . "\n", FILE_APPEND);
    $h .= '<br>Could not connect to API: ' . $url;
    $h .= '<br>Response: code: '.$code . ' message: ' . $message;
  return $h;
  }
    
  if (is_wp_error($response) ) {
    $error_message = $response->get_error_message();
    file_put_contents($filename, "Something went wrong: $error_message", FILE_APPEND);
    return "Something went wrong: $error_message";
  }

  $body=$response['body'];
  file_put_contents($filename, "\n----  body ----\n", FILE_APPEND);
  file_put_contents($filename, $body, FILE_APPEND);

  $decode=json_decode($body,true);
  //file_put_contents($filename, "----  decode ----\n", FILE_APPEND);
  //file_put_contents($filename, $decode, FILE_APPEND);
  
  $transcript = $decode['transcript'];

} else if(isset($_POST['transcript'])) {
  file_put_contents($filename, "Test POST\n", FILE_APPEND);
  $transcript=$_POST['transcript'];
} else {
  file_put_contents($filename, "Test transcript empty\n", FILE_APPEND);
  $transcript='';
}

// Download
if (isset($_POST['download'])){
  file_put_contents($filename, "Test 1\n", FILE_APPEND);
  ob_clean();
  ob_end_clean();
  ob_start(null, 0, PHP_OUTPUT_HANDLER_CLEANABLE);
  header('Content-Type: text/csv');
  header('Content-Disposition: attachment; filename="thomasmoor.org.csv"');
  header('Pragma: no-cache');    
  header('Expires: 0');
  $message = "";
  $fp = fopen('php://output', 'w');
  fwrite($fp, $transcript);
}
  
file_put_contents($filename, "Test F\n", FILE_APPEND);
$h .= "<br/>";
$h .= '<input type="submit" name="download" value="Download"/>';
$h .= '<textarea cols="100" rows="30" name="transcript">';
$h .= $transcript;
$h .= '</textarea>';
file_put_contents($filename, "Test G\n", FILE_APPEND);
  
  
//  foreach($response as $tmp){
//	$it=$tmp.getIterator();
//	// Iterate over the values in the ArrayObject:
//    while( $it->valid() ){
//      $h .= $it->key() . "=" . $it->current() . "<br>\n";
//      $it->next();
//    }
//  }
  
  $h .= '</form>';
  
  return $h;

} // callback

?>